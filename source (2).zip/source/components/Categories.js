import { ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useEffect, useState } from 'react';

const CategoriesList = () => {
    const [categories, setCategories] = useState([]);

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await fetch('http://10.24.31.220:3000/products');
                const data = await response.json();
                
                // Extract unique categories
                const uniqueCategories = [...new Set(data.map(item => item.category))];
                setCategories(uniqueCategories);
            } catch (error) {
                console.error('Error fetching categories:', error);
            }
        };

        fetchCategories();
    }, []);

    return (
        <View style={{ paddingHorizontal: 10 }}>
            <ScrollView horizontal>
                {categories.map((category, index) => (
                    <View key={index} style={styles.category}>
                        <Text style={[styles.txtCategory, index === 0 ? styles.firstCategory : null]}>
                            {category}
                        </Text>
                    </View>
                ))}
            </ScrollView>
        </View>
    );
};

export default CategoriesList;

const styles = StyleSheet.create({
    category: {
        marginVertical: 10,
        borderColor: '#52555A',
        borderEndWidth: 1,
        paddingHorizontal: 10,
        justifyContent: 'center',
    },
    txtCategory: {
        marginHorizontal: 10,
        textAlign: 'center',
        fontSize: 17,
        fontWeight: 'bold',
        color: '#52555A',
    },
    firstCategory: {
        color: 'rgba(124, 74, 74, 0.8)',
        fontSize: 20,
        marginLeft: 0,
    },
});
