// import { FlatList, Image, Pressable, StyleSheet, Text, View, Alert } from 'react-native';
// import React, { useState, useEffect } from 'react';
// import Icon from 'react-native-vector-icons/FontAwesome';
// import { useNavigation } from '@react-navigation/native';

// const FoodCard = () => {
//     const nav = useNavigation();
//     const [cart, setCart] = useState([]);
//     const [products, setProducts] = useState([]);

//     // Fetch data from API
//     useEffect(() => {
//         const fetchProducts = async () => {
//             try {
//                 const response = await fetch('http://192.168.32.102:3000/products');
//                 const data = await response.json();
//                 setProducts(data);
//             } catch (error) {
//                 console.error('Error fetching products:', error);
//             }
//         };

//         fetchProducts();
//     }, []);

//     const addToCart = (item) => {
//         setCart((prevCart) => [...prevCart, item]);
//     };

//     const deleteProduct = async (id) => {
//         Alert.alert("Xác nhận", "Bạn có chắc chắn muốn xóa sản phẩm này?", [
//             { text: "Hủy", style: "cancel" },
//             {
//                 text: "Xóa",
//                 onPress: async () => {
//                     try {
//                         await fetch(`http://192.168.32.102:3000/products/${id}`, { method: 'DELETE' });
//                         setProducts(products.filter(product => product.id !== id));
//                     } catch (error) {
//                         console.error("Error deleting product:", error);
//                     }
//                 }
//             }
//         ]);
//     };

//     return (
//         <View style={{ flex: 1 }}>
//             <FlatList
//                 contentContainerStyle={styles.container}
//                 data={products}
//                 renderItem={({ item }) => (
//                     <Pressable onPress={() => nav.navigate('FoodDetail', { item })} style={styles.itemFood}>
//                         <View>
//                             {item.sale && <Text style={styles.saleText}>Sale</Text>}
//                             <Image style={styles.imgFood} source={{ uri: item.image }} />
//                         </View>
//                         <Text style={styles.itemText}>{item.name}</Text>
//                         <View style={styles.itemInfo}>
//                             <View style={styles.priceContainer}>
//                                 <Text style={styles.price}><Text style={{ color: 'black' }}></Text> {item.price} VND</Text>
//                                 <Pressable style={styles.btnAdd} onPress={() => addToCart(item)}>
//                                     <Icon name='plus' size={15} color='white' />
//                                 </Pressable>
//                             </View>
//                             <View style={styles.actionButtons}>
//                                 <Pressable style={styles.btnEdit} onPress={() => nav.navigate('EditProduct', { item })}>
//                                     <Icon name='pencil' size={18} color='white' />
//                                 </Pressable>
//                                 <Pressable style={styles.btnDelete} onPress={() => deleteProduct(item.id)}>
//                                     <Icon name='trash' size={18} color='white' />
//                                 </Pressable>
//                             </View>
//                         </View>
//                     </Pressable>
//                 )}
//                 keyExtractor={(item) => item.id.toString()}
//                 columnWrapperStyle={{ justifyContent: 'space-between' }}
//                 numColumns={2}
//             />
//         </View>
//     );
// };

// export default FoodCard;

// const styles = StyleSheet.create({
//     container: { paddingVertical: 5 },
//     itemFood: { backgroundColor: 'rgba(188, 192, 187, 0.8)', paddingHorizontal: 12, paddingTop: 15, paddingBottom: 20, marginVertical: 15, marginHorizontal: 10, borderRadius: 15, position: 'relative' },
//     saleText: { position: 'absolute', top: 0, right: 0, backgroundColor: '#f5272799', color: '#FFFFFF', width: 53, height: 22, textAlign: 'center', borderBottomLeftRadius: 25, zIndex: 1, fontWeight: 'bold' },
//     itemText: { color: 'black', alignSelf: 'flex-start', fontSize: 20, marginTop: 10, fontWeight: 'bold' },
//     imgFood: { width: 155, height: 155, resizeMode: 'cover', borderRadius: 15, overflow: 'hidden', borderWidth: 2 },
//     itemInfo: { marginTop: 7, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start' },
//     priceContainer: { flexDirection: 'row', alignItems: 'center' },
//     price: { flex: 1, marginTop: 5, fontSize: 20, color: 'black', fontWeight: 'bold' },
//     btnAdd: { backgroundColor: 'rgba(58, 62, 57, 0.8)', width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 10 },
//     actionButtons: { flexDirection: 'row', marginTop: 10 },
//     btnEdit: { backgroundColor: '#4CAF50', width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 10, marginRight: 5 },
//     btnDelete: { backgroundColor: '#D32F2F', width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 10 }
// });
import { FlatList, Image, Pressable, StyleSheet, Text, View, Alert } from 'react-native';
import React, { useState, useEffect } from 'react';
import Icon from 'react-native-vector-icons/FontAwesome';
import { useNavigation } from '@react-navigation/native';

const FoodCard = () => {
    const nav = useNavigation();
    const [cart, setCart] = useState([]);
    const [products, setProducts] = useState([]);

    // Fetch data from API
    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await fetch('http://10.24.31.220:3000/products');
                const data = await response.json();
                setProducts(data);
            } catch (error) {
                console.error('Error fetching products:', error);
            }
        };

        fetchProducts();
    }, [products]);

    const addToCart = (item) => {
        setCart((prevCart) => [...prevCart, item]);
    };

    const deleteProduct = async (id) => {
        Alert.alert("Xác nhận", "Bạn có chắc chắn muốn xóa sản phẩm này?", [
            { text: "Hủy", style: "cancel" },
            {
                text: "Xóa",
                onPress: async () => {
                    try {
                        await fetch(`http://10.24.31.220:3000/products/${id}`, { method: 'DELETE' });
                        setProducts(products.filter(product => product.id !== id));
                    } catch (error) {
                        console.error("Error deleting product:", error);
                    }
                }
            }
        ]);
    };

    return (
        <View style={{ flex: 1 }}>
            <FlatList
                contentContainerStyle={styles.container}
                data={products}
                renderItem={({ item }) => (
                    <Pressable onPress={() => nav.navigate('FoodDetail', { item })} style={styles.itemFood}>
                        <View>
                            {item.sale && <Text style={styles.saleText}>Sale</Text>}
                            <Image style={styles.imgFood} source={{ uri: item.image }} />
                        </View>
                        <Text style={styles.itemText}>{item.name}</Text>
                        <View style={styles.itemInfo}>
                            <View style={styles.priceContainer}>
                                <Text style={styles.price}><Text style={{ color: 'black' }}></Text> {item.price} VND</Text>
                                <Pressable style={styles.btnAdd} onPress={() => addToCart(item)}>
                                    <Icon name='plus' size={15} color='white' />
                                </Pressable>
                            </View>
                            <View style={styles.actionButtons}>
                                <Pressable style={styles.btnEdit} onPress={() => nav.navigate('EditProduct', { item })}>
                                    <Icon name='pencil' size={18} color='white' />
                                </Pressable>
                                <Pressable style={styles.btnDelete} onPress={() => deleteProduct(item.id)}>
                                    <Icon name='trash' size={18} color='white' />
                                </Pressable>
                            </View>
                        </View>
                    </Pressable>
                )}
                keyExtractor={(item) => item.id.toString()}
                columnWrapperStyle={{ justifyContent: 'space-between' }}
                numColumns={2}
            />
            
            {/* Nút thêm sản phẩm */}
            <Pressable style={styles.addButton} onPress={() => nav.navigate('AddProduct')}>
                <Icon name='plus' size={24} color='white' />
            </Pressable>
        </View>
    );
};

export default FoodCard;

const styles = StyleSheet.create({
    container: { paddingVertical: 5 },
    itemFood: { backgroundColor: 'rgba(188, 192, 187, 0.8)', paddingHorizontal: 12, paddingTop: 15, paddingBottom: 20, marginVertical: 15, marginHorizontal: 10, borderRadius: 15, position: 'relative' },
    saleText: { position: 'absolute', top: 0, right: 0, backgroundColor: '#f5272799', color: '#FFFFFF', width: 53, height: 22, textAlign: 'center', borderBottomLeftRadius: 25, zIndex: 1, fontWeight: 'bold' },
    itemText: { color: 'black', alignSelf: 'flex-start', fontSize: 20, marginTop: 10, fontWeight: 'bold' },
    imgFood: { width: 155, height: 155, resizeMode: 'cover', borderRadius: 15, overflow: 'hidden', borderWidth: 2 },
    itemInfo: { marginTop: 7, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start' },
    priceContainer: { flexDirection: 'row', alignItems: 'center' },
    price: { flex: 1, marginTop: 5, fontSize: 20, color: 'black', fontWeight: 'bold' },
    btnAdd: { backgroundColor: 'rgba(58, 62, 57, 0.8)', width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 10 },
    actionButtons: { flexDirection: 'row', marginTop: 10 },
    btnEdit: { backgroundColor: '#4CAF50', width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 10, marginRight: 5 },
    btnDelete: { backgroundColor: '#D32F2F', width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 10 },
    addButton: { position: 'absolute', bottom: 20, right: 20, backgroundColor: '#4CAF50', width: 60, height: 60, alignItems: 'center', justifyContent: 'center', borderRadius: 30, elevation: 5 }
});
