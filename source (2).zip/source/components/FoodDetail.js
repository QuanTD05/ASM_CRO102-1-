import React, { useState } from 'react';
import { 
    StyleSheet, Text, View, TouchableOpacity, 
    ScrollView, Pressable, StatusBar, Image, Alert 
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/FontAwesome';

const FoodDetail = ({ navigation, route }) => {
    const { item } = route.params;
    const [selectedSize, setSelectedSize] = useState('M'); // Chọn size mặc định là M

    const sizes = ['S', 'M', 'L'];

    const addToCart = async () => {
        try {
            const cartData = await AsyncStorage.getItem('cart');
            let cart = cartData ? JSON.parse(cartData) : [];

            const existingIndex = cart.findIndex(cartItem => cartItem.id === item.id && cartItem.size === selectedSize);
            if (existingIndex !== -1) {
                cart[existingIndex].quantity += 1;
            } else {
                cart.push({ ...item, quantity: 1, size: selectedSize });
            }

            await AsyncStorage.setItem('cart', JSON.stringify(cart));
            console.log("Cart after adding item:", cart); // 🛠 Kiểm tra log

            Alert.alert('Success', 'Added to cart successfully!');
            navigation.navigate('Cart');
        } catch (error) {
            console.error('Error adding to cart:', error);
        }
    };

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <Pressable style={{ flex: 1 }} onPress={() => navigation.goBack()} >
                    <Icon name='arrow-circle-left' size={30} color='#333' />
                </Pressable>
                <Icon name='heart-o' size={30} color='#333' />
            </View>
            <ScrollView contentContainerStyle={styles.scrollContainer}>
                <View style={styles.contentBox}>
                    <Image source={{ uri: item.image }} style={styles.itemImage} resizeMode='cover' />
                    <Text style={styles.itemName}>{item.name}</Text>
                    <Text style={styles.itemCategory}>{item.category}</Text>
                    <View style={{ height: 100 }}>
                        <Text style={styles.itemDescription}>{item.description}</Text>
                    </View>

                    {/* Chọn Size */}
                    <View style={styles.sizeField}>
                        <Text style={styles.sizeTitle}>Size</Text>
                        <View style={styles.sizeContainer}>
                            {sizes.map((size, index) => (
                                <TouchableOpacity 
                                    key={index} 
                                    style={[styles.sizeBox, selectedSize === size && styles.selectedSize]}
                                    onPress={() => setSelectedSize(size)}
                                >
                                    <Text style={styles.sizeText}>{size}</Text>
                                </TouchableOpacity>
                            ))}
                        </View>
                    </View>

                    <View style={styles.totalField}>
                        <View style={styles.priceField}>
                            <Text style={styles.priceLabel}>Giá</Text>
                            <Text style={styles.txtPrice}>
                                <Text style={styles.priceSymbol}></Text> {item.price} VND
                            </Text>
                        </View>
                        {/* Nút Thêm vào Giỏ Hàng */}
                        <Pressable style={styles.btnAdd} onPress={addToCart}>
                            <Text style={styles.btnAddText}>Thêm vào giỏ hàng</Text>
                        </Pressable>
                    </View>
                </View>
            </ScrollView>
        </View>
    );
};

export default FoodDetail;

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f9f9f9' },
    header: { marginTop: StatusBar.currentHeight, flexDirection: 'row', marginHorizontal: 15, alignItems: 'center', justifyContent: 'space-between' },
    scrollContainer: { flexGrow: 1, justifyContent: 'flex-start', alignItems: 'center' },
    contentBox: { flex: 1, marginTop: 10, borderTopLeftRadius: 55, borderTopRightRadius: 55, alignItems: 'flex-start', paddingHorizontal: 20, paddingBottom: 20, backgroundColor: '#ffffff', width: '100%', elevation: 5 },
    itemImage: { width: '100%', height: 300, borderTopLeftRadius: 55, borderTopRightRadius: 55 },
    itemName: { fontSize: 45, color: '#333', marginTop: 20 },
    itemCategory: { fontSize: 18, color: '#555', marginTop: 5, fontWeight: '700', backgroundColor: 'rgba(234, 221, 228, 0.5)', padding: 5, borderRadius: 10 },
    itemDescription: { fontSize: 16, color: '#555', marginTop: 10, textAlign: 'auto', letterSpacing: 1 },
    sizeField: { marginTop: 15, width: '100%', height: 75 },
    sizeTitle: { fontSize: 22, color: '#333', fontWeight: 'bold' },
    sizeContainer: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 },
    sizeBox: { flex: 1, marginHorizontal: 10, alignItems: 'center', justifyContent: 'center', paddingVertical: 10, borderRadius: 12, borderColor: 'rgba(161, 240, 90, 0.8)', borderWidth: 2 },
    selectedSize: { backgroundColor: 'rgba(161, 240, 90, 0.8)' },
    sizeText: { color: '#333', fontSize: 16, fontWeight: 'bold' },
    totalField: { justifyContent: 'center', alignSelf: 'center', alignItems: 'center', marginTop: 50, flexDirection: 'row', width: '100%' },
    btnAdd: { backgroundColor: 'rgba(161, 240, 90, 0.9)', width: '65%', height: 60, alignItems: 'center', justifyContent: 'center', borderRadius: 20 },
    btnAddText: { color: '#000', fontSize: 20, fontWeight: 'bold' },
});
