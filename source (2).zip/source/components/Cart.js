import React, { useState, useEffect } from 'react';
import { 
    View, Text, FlatList, StyleSheet, TouchableOpacity, 
    Alert, Image 
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/FontAwesome';

const Cart = ({ navigation }) => {
    const [cartItems, setCartItems] = useState([]);

    // Load giỏ hàng khi màn hình focus
    useFocusEffect(
        React.useCallback(() => {
            const loadCart = async () => {
                try {
                    const cartData = await AsyncStorage.getItem('cart');
                    if (cartData) {
                        setCartItems(JSON.parse(cartData));
                    }
                } catch (error) {
                    console.error("Error loading cart:", error);
                }
            };
            loadCart();
        }, [])
    );

    // Cập nhật giỏ hàng vào AsyncStorage
    const updateCart = async (newCart) => {
        try {
            await AsyncStorage.setItem('cart', JSON.stringify(newCart));
            setCartItems(newCart);
        } catch (error) {
            console.error("Error updating cart:", error);
        }
    };

    // Xóa một sản phẩm khỏi giỏ hàng
    const removeItem = (index) => {
        Alert.alert(
            "Remove Item",
            "Are you sure you want to remove this item?",
            [
                { text: "Cancel", style: "cancel" },
                { 
                    text: "Remove", 
                    onPress: () => {
                        const updatedCart = [...cartItems];
                        updatedCart.splice(index, 1);
                        updateCart(updatedCart);
                    },
                    style: "destructive" 
                }
            ]
        );
    };

    // Tăng số lượng sản phẩm
    const increaseQuantity = (index) => {
        const updatedCart = [...cartItems];
        updatedCart[index].quantity += 1;
        updateCart(updatedCart);
    };

    // Giảm số lượng sản phẩm (nếu > 1 thì giảm, nếu =1 thì hỏi có xóa không)
    const decreaseQuantity = (index) => {
        const updatedCart = [...cartItems];
        if (updatedCart[index].quantity > 1) {
            updatedCart[index].quantity -= 1;
            updateCart(updatedCart);
        } else {
            removeItem(index);
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Giỏ hàng của bạn</Text>

            {cartItems.length === 0 ? (
                <Text style={styles.emptyCart}>Your cart is empty.</Text>
            ) : (
                <FlatList
                    data={cartItems}
                    keyExtractor={(item, index) => index.toString()}
                    renderItem={({ item, index }) => (
                        <View style={styles.cartItem}>
                            <Image source={{ uri: item.image }} style={styles.itemImage} />
                            <View style={styles.itemDetails}>
                                <Text style={styles.itemName}>{item.name}</Text>
                                <Text style={styles.itemSize}>Size: {item.size}</Text>
                                <Text style={styles.itemPrice}>{item.price} VND</Text>
                                <View style={styles.quantityControl}>
                                    <TouchableOpacity onPress={() => decreaseQuantity(index)} style={styles.quantityButton}>
                                        <Icon name="minus" size={18} color="white" />
                                    </TouchableOpacity>
                                    <Text style={styles.quantityText}>{item.quantity}</Text>
                                    <TouchableOpacity onPress={() => increaseQuantity(index)} style={styles.quantityButton}>
                                        <Icon name="plus" size={18} color="white" />
                                    </TouchableOpacity>
                                </View>
                            </View>
                            <TouchableOpacity onPress={() => removeItem(index)}>
                                <Icon name="trash" size={24} color="red" />
                            </TouchableOpacity>
                        </View>
                    )}
                />
            )}

            {/* Tổng tiền */}
            {cartItems.length > 0 && (
                <View style={styles.totalContainer}>
                    <Text style={styles.totalText}>
                        Tổng tiền: {cartItems.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2)} VND
                    </Text>
                    <TouchableOpacity 
    style={styles.checkoutButton} 
    onPress={() => navigation.navigate('Checkout')}
>
    <Text style={styles.checkoutText}>Thanh toán</Text>
</TouchableOpacity>

                </View>
            )}
        </View>
    );
};

export default Cart;

const styles = StyleSheet.create({
    container: { flex: 1, padding: 20, backgroundColor: '#f9f9f9' },
    title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
    emptyCart: { fontSize: 18, color: 'gray', marginTop: 20, textAlign: 'center' },

    cartItem: { 
        flexDirection: 'row', 
        alignItems: 'center', 
        backgroundColor: '#fff', 
        padding: 10, 
        borderRadius: 10, 
        marginBottom: 10, 
        shadowColor: '#000', 
        shadowOpacity: 0.1, 
        shadowRadius: 5, 
        elevation: 3 
    },
    itemImage: { width: 70, height: 70, borderRadius: 10, marginRight: 10 },
    itemDetails: { flex: 1 },
    itemName: { fontSize: 18, fontWeight: 'bold', color: '#333' },
    itemSize: { fontSize: 14, color: '#555' },
    itemPrice: { fontSize: 16, fontWeight: 'bold', color: '#000', marginTop: 5 },

    quantityControl: { flexDirection: 'row', alignItems: 'center', marginTop: 10 },
    quantityButton: { 
        backgroundColor: 'green', 
        padding: 5, 
        borderRadius: 5, 
        marginHorizontal: 10 
    },
    quantityText: { fontSize: 16, fontWeight: 'bold', color: '#333' },

    totalContainer: { 
        marginTop: 20, 
        padding: 15, 
        borderRadius: 10, 
        backgroundColor: '#fff', 
        shadowColor: '#000', 
        shadowOpacity: 0.1, 
        shadowRadius: 5, 
        elevation: 3, 
        alignItems: 'center' 
    },
    totalText: { fontSize: 20, fontWeight: 'bold' },
    checkoutButton: { 
        backgroundColor: 'green', 
        paddingVertical: 12, 
        paddingHorizontal: 20, 
        borderRadius: 10, 
        marginTop: 10 
    },
    checkoutText: { fontSize: 18, color: 'white', fontWeight: 'bold' }
});
