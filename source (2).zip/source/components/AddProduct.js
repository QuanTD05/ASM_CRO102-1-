import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Text, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const AddProduct = () => {
    const nav = useNavigation();
    const [name, setName] = useState('');
    const [category, setCategory] = useState('');
    const [description, setDescription] = useState('');
    const [price, setPrice] = useState('');
    const [image, setImage] = useState('');
    const [sale, setSale] = useState(false);

    const handleAddProduct = async () => {
        if (!name || !category || !description || !price || !image) {
            Alert.alert('Lỗi', 'Vui lòng nhập đầy đủ thông tin.');
            return;
        }

        const newProduct = {
            id: Math.random().toString(36).substr(2, 9), // Tạo id ngẫu nhiên
            name,
            category,
            description,
            price: parseFloat(price),
            image,
            sale,
        };

        try {
            await fetch('http://10.24.31.220:3000/products', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newProduct),
            });

            Alert.alert('Thành công', 'Sản phẩm đã được thêm!');
            nav.goBack();
        } catch (error) {
            console.error('Lỗi thêm sản phẩm:', error);
            Alert.alert('Lỗi', 'Không thể thêm sản phẩm');
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Thêm Sản Phẩm</Text>
            <TextInput style={styles.input} placeholder="Tên sản phẩm" value={name} onChangeText={setName} />
            <TextInput style={styles.input} placeholder="Loại sản phẩm" value={category} onChangeText={setCategory} />
            <TextInput style={styles.input} placeholder="Mô tả" value={description} onChangeText={setDescription} />
            <TextInput style={styles.input} placeholder="Giá" keyboardType="numeric" value={price} onChangeText={setPrice} />
            <TextInput style={styles.input} placeholder="URL Hình ảnh" value={image} onChangeText={setImage} />
            <Button title="Thêm sản phẩm" onPress={handleAddProduct} />
        </View>
    );
};

export default AddProduct;

const styles = StyleSheet.create({
    container: { flex: 1, padding: 20 },
    title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
    input: { height: 40, borderColor: 'gray', borderWidth: 1, marginBottom: 10, paddingHorizontal: 10, borderRadius: 5 },
});
