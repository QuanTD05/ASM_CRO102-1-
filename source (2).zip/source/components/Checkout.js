import { View, Text, FlatList, Image, TextInput, Pressable, StyleSheet, Alert } from 'react-native';
import React, { useEffect, useState } from 'react';

const userId = 2; // Giả sử userId của người dùng hiện tại

const Checkout = () => {
    const [cartItems, setCartItems] = useState([]);
    const [products, setProducts] = useState([]);
    const [address, setAddress] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('COD'); // COD: Thanh toán khi nhận hàng

    useEffect(() => {
        const fetchCartData = async () => {
            try {
                const response = await fetch('http://10.24.31.220:3000/carts');
                const data = await response.json();
                const userCart = data.find(cart => cart.userId === userId);

                const productResponse = await fetch('http://10.24.31.220:3000/products');
                const productData = await productResponse.json();
                setProducts(productData);

                if (userCart) {
                    const cartDetails = userCart.items.map(item => {
                        const product = productData.find(p => p.id === item.productId);
                        return product ? { ...product, quantity: item.quantity } : null;
                    }).filter(item => item !== null);

                    setCartItems(cartDetails);
                }
            } catch (error) {
                console.error('Error fetching cart data:', error);
            }
        };

        fetchCartData();
    }, []);

    // Tính tổng tiền
    const totalAmount = cartItems.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2);

    // Xử lý đặt hàng
    const handleOrder = async () => {
        if (!address) {
            Alert.alert('Lỗi', 'Vui lòng nhập địa chỉ giao hàng!');
            return;
        }

        const orderData = {
            userId: userId,
            items: cartItems.map(item => ({
                productId: item.id,
                quantity: item.quantity
            })),
            totalPrice: parseFloat(totalAmount),
            status: 'Pending', // Trạng thái đơn hàng ban đầu
            paymentMethod: paymentMethod,
            address: address
        };

        try {
            const response = await fetch('http://10.24.31.220:3000/orders', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(orderData)
            });

            if (response.ok) {
                Alert.alert('Thành công', 'Đơn hàng của bạn đã được đặt thành công!');
                setCartItems([]); // Xóa giỏ hàng sau khi đặt hàng thành công
                setAddress('');
            } else {
                Alert.alert('Lỗi', 'Đặt hàng không thành công, vui lòng thử lại.');
            }
        } catch (error) {
            console.error('Error placing order:', error);
            Alert.alert('Lỗi', 'Có lỗi xảy ra khi đặt hàng.');
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Xác nhận đơn hàng</Text>

            {/* Danh sách sản phẩm trong giỏ hàng */}
            <FlatList
                data={cartItems}
                renderItem={({ item }) => (
                    <View style={styles.cartItem}>
                        <Image source={{ uri: item.image }} style={styles.image} />
                        <View style={styles.info}>
                            <Text style={styles.name}>{item.name}</Text>
                            <Text style={styles.price}>${item.price} x {item.quantity}</Text>
                        </View>
                    </View>
                )}
                keyExtractor={item => item.id.toString()}
            />

            {/* Nhập địa chỉ giao hàng */}
            <Text style={styles.label}>Địa chỉ giao hàng:</Text>
            <TextInput
                style={styles.input}
                placeholder="Nhập địa chỉ của bạn"
                value={address}
                onChangeText={setAddress}
            />

            {/* Chọn phương thức thanh toán */}
            <Text style={styles.label}>Phương thức thanh toán:</Text>
            <View style={styles.paymentContainer}>
                <Pressable
                    style={[styles.paymentButton, paymentMethod === 'COD' && styles.paymentSelected]}
                    onPress={() => setPaymentMethod('COD')}
                >
                    <Text style={styles.paymentText}>Thanh toán khi nhận hàng</Text>
                </Pressable>
                <Pressable
                    style={[styles.paymentButton, paymentMethod === 'Online' && styles.paymentSelected]}
                    onPress={() => setPaymentMethod('Online')}
                >
                    <Text style={styles.paymentText}>Thanh toán Online</Text>
                </Pressable>
            </View>

            {/* Tổng tiền */}
            <Text style={styles.total}>Tổng tiền: ${totalAmount}</Text>

            {/* Nút đặt hàng */}
            <Pressable style={styles.btnOrder} onPress={handleOrder}>
                <Text style={styles.btnOrderText}>Đặt hàng</Text>
            </Pressable>
        </View>
    );
};

export default Checkout;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#F5F5F5',
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
        marginBottom: 10,
    },
    cartItem: {
        flexDirection: 'row',
        backgroundColor: 'white',
        padding: 10,
        borderRadius: 10,
        marginBottom: 10,
        alignItems: 'center',
        elevation: 3,
    },
    image: {
        width: 80,
        height: 80,
        borderRadius: 10,
    },
    info: {
        flex: 1,
        marginLeft: 10,
    },
    name: {
        fontSize: 16,
        fontWeight: 'bold',
    },
    price: {
        fontSize: 14,
        color: 'gray',
        marginVertical: 5,
    },
    label: {
        fontSize: 16,
        fontWeight: 'bold',
        marginVertical: 5,
    },
    input: {
        backgroundColor: 'white',
        padding: 10,
        borderRadius: 10,
        marginBottom: 10,
        fontSize: 16,
    },
    paymentContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10,
    },
    paymentButton: {
        flex: 1,
        padding: 10,
        backgroundColor: '#ddd',
        borderRadius: 10,
        alignItems: 'center',
        marginHorizontal: 5,
    },
    paymentSelected: {
        backgroundColor: '#28A745',
    },
    paymentText: {
        color: 'white',
        fontWeight: 'bold',
    },
    total: {
        fontSize: 18,
        fontWeight: 'bold',
        textAlign: 'center',
        marginVertical: 10,
    },
    btnOrder: {
        backgroundColor: '#D9534F',
        paddingVertical: 12,
        borderRadius: 10,
        alignItems: 'center',
    },
    btnOrderText: {
        color: 'white',
        fontSize: 18,
        fontWeight: 'bold',
    },
});
