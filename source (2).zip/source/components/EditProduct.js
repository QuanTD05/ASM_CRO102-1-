import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, Switch } from 'react-native';
import { useNavigation, useRoute, useFocusEffect } from '@react-navigation/native';

const EditProduct = () => {
    const route = useRoute();
    const nav = useNavigation();
    const { item } = route.params;

    const [name, setName] = useState(item.name);
    const [price, setPrice] = useState(item.price.toString());
    const [image, setImage] = useState(item.image);
    const [category, setCategory] = useState(item.category);
    const [description, setDescription] = useState(item.description);
    const [sale, setSale] = useState(item.sale);

    const updateProduct = async () => {
        try {
            const response = await fetch(`http://10.24.31.220:3000/products/${item.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, price: parseFloat(price), image, category, description, sale })
            });
            
            if (response.ok) {
                Alert.alert("Thành công", "Sản phẩm đã được cập nhật");
                nav.goBack();
            } else {
                Alert.alert("Lỗi", "Cập nhật sản phẩm thất bại");
            }
        } catch (error) {
            console.error("Lỗi khi cập nhật sản phẩm:", error);
        }
    };

    useFocusEffect(
        useCallback(() => {
            // Reload product list when returning to the screen
            return () => {
                fetch(`http://10.24.31.220:3000/products/${item.id}`)
                    .then(res => res.json())
                    .then(updatedItem => {
                        setName(updatedItem.name);
                        setPrice(updatedItem.price.toString());
                        setImage(updatedItem.image);
                        setCategory(updatedItem.category);
                        setDescription(updatedItem.description);
                        setSale(updatedItem.sale);
                    })
                    .catch(error => console.error("Lỗi khi tải sản phẩm:", error));
            };
        }, [item.id])
    );

    return (
        <View style={styles.container}>
            <Text style={styles.label}>Tên sản phẩm:</Text>
            <TextInput style={styles.input} value={name} onChangeText={setName} />
            
            <Text style={styles.label}>Giá sản phẩm:</Text>
            <TextInput style={styles.input} value={price} onChangeText={setPrice} keyboardType='numeric' />
            
            <Text style={styles.label}>Danh mục:</Text>
            <TextInput style={styles.input} value={category} onChangeText={setCategory} />
            
            <Text style={styles.label}>Mô tả:</Text>
            <TextInput style={styles.input} value={description} onChangeText={setDescription} multiline />
            
            <Text style={styles.label}>URL hình ảnh:</Text>
            <TextInput style={styles.input} value={image} onChangeText={setImage} />
            
            <View style={styles.switchContainer}>
                <Text style={styles.label}>Giảm giá:</Text>
                <Switch value={sale} onValueChange={setSale} />
            </View>
            
            <Button title="Lưu thay đổi" onPress={updateProduct} />
        </View>
    );
};

export default EditProduct;

const styles = StyleSheet.create({
    container: { flex: 1, padding: 20, backgroundColor: 'white' },
    label: { fontSize: 16, fontWeight: 'bold', marginBottom: 5 },
    input: { borderWidth: 1, borderColor: '#ccc', padding: 10, marginBottom: 15, borderRadius: 5 },
    switchContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 }
});
