import React, { useEffect } from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const SplashScreen = ({ navigation }) => {
    useEffect(() => {
        setTimeout(() => {
            navigation.replace('Login');
        }, 3000);
    }, []);

    return (
        <View style={styles.container}>
            {/* <Image source={require('./images/vb.jpg')} style={styles.logo} /> */}
            <Text style={styles.info}>Họ tên: Trần Đình Quân</Text>
            <Text style={styles.info}>Mã SV: PH54567</Text>
            <Text style={styles.info}>Lớp: MD19303</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    logo: { width: 300, height: 300, marginBottom: 20 },
    info: { fontSize: 18, color: 'red' }
});

export default SplashScreen;
