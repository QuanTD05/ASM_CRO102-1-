import React, { useState } from 'react';
import { 
    Dimensions, Image, ImageBackground, SafeAreaView, StatusBar, 
    StyleSheet, Text, TextInput, TouchableOpacity, View, Alert
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;

const Login = ({ navigation }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = async () => {
        try {
            const response = await fetch('http://10.24.31.220:3000/users'); 
            const users = await response.json();
            
            const user = users.find(u => u.email === email && u.pwd === password);
            if (user) {
                await AsyncStorage.setItem('userId', user.id.toString()); // Lưu userId vào AsyncStorage
                Alert.alert('Thành công', 'Đăng nhập thành công');
                navigation.navigate('Home');
            } else {
                Alert.alert('Lỗi', 'Email hoặc mật khẩu không hợp lệ');
            }
        } catch (error) {
            Alert.alert('Lỗi', 'Có gì đó không ổn');
            console.error(error);
        }
    };

    return (
        <ImageBackground style={styles.bgLogin} source={require('../images/logo_cafe.jpg')}>
            <StatusBar backgroundColor="transparent" translucent barStyle="light-content" />
            <SafeAreaView style={{ flex: 1 }}>
                <View style={{ width: '100%', height: '100%' }}>
                    <View style={styles.logoContainer}>
                        <View style={styles.logoBackground}>
                            <Image style={styles.logo} source={require('../images/logo2.jpg')} />
                        </View>
                    </View>
                    <View style={styles.welcomeContainer}>
                        <Text style={styles.welcomeText}>Welcome to Cafe</Text>
                        <Text style={styles.loginText}>Đăng Nhập Để Tiếp Tục</Text>
                    </View>
                    <View style={styles.boxInput}>
                        <View style={styles.fieldLogin}>
                            <TextInput 
                                style={styles.emailInput} 
                                placeholder='Email Address' 
                                value={email}
                                onChangeText={setEmail}
                            />
                        </View>
                        <View style={styles.fieldLogin}>
                            <TextInput 
                                style={styles.passwordInput} 
                                placeholder='Password' 
                                secureTextEntry={true} 
                                value={password}
                                onChangeText={setPassword}
                            />
                        </View>
                    </View>
                    <View style={styles.signInField}>
                        <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
                            <Text style={styles.buttonText}>Login</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.RegisterField}>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={{ color: 'white', fontSize: 15, fontWeight: 'bold', marginEnd: 5 }}>
                                Don't have an account? Click
                            </Text>
                            <TouchableOpacity onPress={() => navigation.navigate('Register')}>
                                <Text style={{ color: 'cyan', fontSize: 15, fontWeight: 'bold' }}>Register</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </SafeAreaView>
        </ImageBackground>
    );
};

export default Login;

const styles = StyleSheet.create({
    bgLogin: {
        width: '100%',
        height: '100%',
        resizeMode: 'stretch',
    },
    boxInput: {
        width: '100%',
        height: '20%',
        alignItems: 'center',
    },
    logoContainer: {
        alignItems: 'center',
        marginTop: 0.09 * deviceHeight,
    },
    logoBackground: {
        width: 125,
        height: 125,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F1FFFF',
        borderRadius: 100,
        opacity: 0.8,
    },
    logo: {
        width: 140,
        height: 140,
        borderRadius: 15,
    },
    fieldLogin: {
        paddingHorizontal: 20,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginVertical: 10,
    },
    emailInput: {
        backgroundColor: '#fff',
        height: 55,
        width: '97%',
        borderWidth: 1,
        borderColor: '#7a7d82',
        borderRadius: 10,
        paddingHorizontal: 20,
    },
    passwordInput: {
        backgroundColor: '#fff',
        height: 55,
        width: '97%',
        borderWidth: 1,
        borderColor: '#7a7d82',
        borderRadius: 10,
        paddingHorizontal: 20,
    },
    welcomeContainer: {
        alignItems: 'center',
        marginTop: 20,
    },
    welcomeText: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#FFFFFF',
    },
    loginText: {
        fontSize: 18,
        color: 'black',
        fontWeight: 'bold',
        backgroundColor: 'white',
        padding: 8,
        borderRadius: 20,
        marginTop: 5,
    },
    signInField: {
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    loginButton: {
        width: '85%',
        height: 50,
        borderColor: 'white',
        borderWidth: 1,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#00b56bbf',
    },
    buttonText: {
        color: 'white',
        fontSize: 20,
        fontWeight: 'bold',
    },
    RegisterField: {
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    }
});
