import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Cart = () => {
    return (
        <View>
            <Text>Cart</Text>
        </View>
    )
}

export default Cart

const styles = StyleSheet.create({})